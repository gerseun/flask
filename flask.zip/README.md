LINK REMOTE MYPHP
https://remotemysql.com/phpmyadmin/index.php

LINK DB GRAFICO
https://dbdiagram.io/d/5dcc0e5bedf08a25543de0bb

CODICI FUNZIONI DI LAVORO
iniziali
      "0">scegliere
      "1">Da ordinare
      "2">Da Tagliare
      "3">Verificare a mag
      "4">Ufficio Tecnico
acquisti      
      "5">Ordinato
      "6">Materiale Arrivato
taglio
      "1">Da ordinare
      "7">Mat tagliato
carico
      "8">Carico grezzo
      "9">Carico parz lavorato
      "10">Carico finito
prod isorella
      "11">Inizio prod Isorella
      "12">Fine prod Isorella
      "13">Parziale prod Isorella
magazzino
      "14">Presenza totale
      "15">Presenza parziale
      "1">Da ordinare
      "5">Ordinato
